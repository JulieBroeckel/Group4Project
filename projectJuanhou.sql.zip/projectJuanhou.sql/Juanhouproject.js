const mysql = require('mysql');
// use the settings from your cloud database
const conn = mysql.createConnection({
  host: 'den1.mysql1.gear.host',
  database: 'assi5juanhou',
  user: 'assi5juanhou',
  password: 'Pi381_Dg9e~r'
});
conn.query('SELECT * FROM student AS S INNER JOIN   enrollment AS E ON s.student_id = E.student_id   INNER JOIN    course AS C ON E.course_id = C.course_id ORDER BY s.student_id', (err, result) => {  if(err) throw err;  
console.log('Running "SELECT * FROM Student AS S INNER JOIN    enrollment AS E ON s.student_id = E.student_id  INNER JOIN  course AS C ON E.course_id = C.course_id ORDER BY s.student_id" on' + conn.config.host);
  var str = JSON.stringify(result, null, 2);
  console.log(str);
});
X:\myapp>node Juanhouproject.js
X:\myapp\Juanhouproject.js:13
}');
^


X:\myapp>node Juanhouproject.js
Running "SELECT * FROM Student AS S INNER JOIN    enrollment AS E ON s.student_id = E.student_id  INNER JOIN  course AS C ON E.course_id = C.course_id ORDER BY s.student_id" onden1.mysql1.gear.host
[
  {
    "student_id": 1,
    "student_name": "John",
    "year_of_birth": 1990,
    "city": "Bellevue",
    "zip_code": "98007",
    "country": "USA",
    "course_id": "CSD138",
    "course_name": "SQL",
    "credits": 5
  },
  {
    "student_id": 1,
    "student_name": "John",
    "year_of_birth": 1990,
    "city": "Bellevue",
    "zip_code": "98007",
    "country": "USA",
    "course_id": "CSD122",
    "course_name": "JavaScript",
    "credits": 4
  },
  {
    "student_id": 1,
    "student_name": "John",
    "year_of_birth": 1990,
    "city": "Bellevue",
    "zip_code": "98007",
    "country": "USA",
    "course_id": "CSD123",
    "course_name": "C++",
    "credits": 3
  },
  {
    "student_id": 2,
    "student_name": "Bill",
    "year_of_birth": 1988,
    "city": "Redmond",
    "zip_code": "98052",
    "country": "USA",
    "course_id": "CSD138",
    "course_name": "SQL",
    "credits": 5
  },
  {
    "student_id": 3,
    "student_name": "George",
    "year_of_birth": 1995,
    "city": "Kirkland",
    "zip_code": "98034",
    "country": "USA",
    "course_id": "CSD123",
    "course_name": "C++",
    "credits": 3
  },
  {
    "student_id": 5,
    "student_name": "Jane",
    "year_of_birth": 2000,
    "city": "Seattle",
    "zip_code": "98101",
    "country": "USA",
    "course_id": "CSD138",
    "course_name": "SQL",
    "credits": 5
  },
  {
    "student_id": 5,
    "student_name": "Jane",
    "year_of_birth": 2000,
    "city": "Seattle",
    "zip_code": "98101",
    "country": "USA",
    "course_id": "CSD122",
    "course_name": "JavaScript",
    "credits": 4
  }
]
